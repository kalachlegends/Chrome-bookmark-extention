// chrome.runtime.onInstalled.addListener(details => {
//     // chrome.contextMenus.create({
//     //     title: "telegram https://t.me/Kpekbang",
//     //     id: "support_menu",
//     //     "contexts": ["action"]
//     // });
  
//     chrome.contextMenus.onClicked.addListener(function onclick(tab, info) {
//         alert("https://github.com/kalachlegends")
//     });
// });